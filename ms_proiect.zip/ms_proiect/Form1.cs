﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cerc_polar_5_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chart1.Series[0].Points.Clear();
            chart1.Series[1].Points.Clear();
            for(double t=-1;t<=1;t+=0.001)
            {
                chart1.Series[0].Points.AddXY(t, Math.Sqrt(1 - t * t));
                chart1.Series[1].Points.AddXY(t, -Math.Sqrt(1 - t * t));

            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            double U1, U2, V1, V2, X1, X2, S,probabilitate;
            int n, i, j;
            double nr_posibile=0.0;

            Random r = new Random();
            n = Convert.ToInt32(textBox1.Text);
            chart1.Series[2].Points.Clear();
            textBox2.Clear();
            j = 0;
            for (i = 0; i < n; i++)
            {
                do
                {
                    U1 = r.NextDouble();
                    U2 = r.NextDouble();
                    V1 = 2 * U1 - 1;
                    V2 = 2 * U2 - 1;
                    S = V1 * V1 + V2 * V2;
                    chart1.Series[2].Points.AddXY(V1, V2);
                    if (S > 1)
                    {
                        chart1.Series[2].Points[j].Color = Color.Red;
                        chart1.Series[2].Points[j].MarkerStyle =
                       System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Star5;
                    }
                    else chart1.Series[2].Points[j].Color = Color.Green;
                    j++;
                }
                while (S > 1);
                X1 = V1 * Math.Sqrt(-2 * Math.Log(S) / S);
                X2 = V2 * Math.Sqrt(-2 * Math.Log(S) / S);
                 if ((X1 < 0 && X2 > 0 )|| (X1 >0 && X2<0))
                { nr_posibile++; }
               
                textBox2.AppendText("\r\nExperimentul " + (i + 1).ToString() + ": ");
                textBox2.AppendText("\r\nX1 = " + X1.ToString());
                textBox2.AppendText("\r\nX2 = " + X2.ToString());
                textBox2.AppendText("\r\n=======================");
               
                
                textBox2.AppendText("\r\n  Nr posibile pt ca ambele nr sa fie cu semne opuse: " + nr_posibile.ToString());
                
            }
            probabilitate = Convert.ToDouble(nr_posibile / n);
            textBox2.AppendText("\r\n Probabilitatea pt ca ambele nr sa fie cu semne opuse: " + (nr_posibile/n).ToString());

        }
    }
}
